const express = require('express');
const { Pool } = require('pg');
const app = express();
app.use(express.json());

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Fail fast with a clear message if the DB is not configured.
let dbConfigured = !!process.env.DATABASE_URL;
if (!dbConfigured) {
  console.warn('[backend] DATABASE_URL is not set. /api/reports will return 503.');
}

pool.on('error', (err) => {
  console.error('[backend] Postgres pool error:', err);
});


// Endpoint Principal: Recebe coordenadas e faz o Georoteamento automático via PostGIS
app.post('/api/reports', async (req, res) => {
  if (!dbConfigured) {
    return res.status(503).json({ error: 'Serviço indisponível: DATABASE_URL ausente.' });
  }

  // Basic request validation (prevent PostGIS failures / NaN issues)
  const body = req.body ?? {};

  const userId = body.userId;
  const latitudeRaw = body.latitude;
  const longitudeRaw = body.longitude;
  const accuracyRaw = body.accuracy;
  // Accept `category` (current web frontend) and fall back to the older
  // `wasteType` key for backward compatibility with any other client.
  const categoryRaw = body.category ?? body.wasteType;

  const latitude = Number(latitudeRaw);
  const longitude = Number(longitudeRaw);
  const accuracy = Number(accuracyRaw);

  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) {
    return res.status(400).json({ error: 'Parâmetro latitude inválido.' });
  }
  if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
    return res.status(400).json({ error: 'Parâmetro longitude inválido.' });
  }
  if (!Number.isFinite(accuracy)) {
    return res.status(400).json({ error: 'Parâmetro accuracy inválido.' });
  }
  if (accuracy > 50) {
    return res.status(400).json({ error: 'Sinal de GPS fraco (precisão > 50m). Altere o pin manualmente.' });
  }

  const VALID_CATEGORIES = ['lixo', 'desmatamento', 'incendio'];
  if (!VALID_CATEGORIES.includes(categoryRaw)) {
    return res.status(400).json({ error: `Parâmetro category inválido. Use um de: ${VALID_CATEGORIES.join(', ')}.` });
  }
  const category = categoryRaw;

  // No user accounts exist yet in the frontend, so userId is optional:
  // reports.user_id is nullable (ON DELETE SET NULL). If it IS provided,
  // it must be a valid number.
  let normalizedUserId = null;
  if (userId !== undefined && userId !== null && userId !== '') {
    if (!Number.isFinite(Number(userId))) {
      return res.status(400).json({ error: 'Parâmetro userId inválido.' });
    }
    normalizedUserId = Number(userId);
  }

  try {
    // Consulta Espacial Avançada usando ST_Contains
    const spatialQuery = `
      SELECT id, name, contact_email 
      FROM authorities 
      WHERE ST_Contains(geom, ST_SetSRID(ST_Point($1, $2), 4326))
      LIMIT 1;
    `;
    
    const geoCheck = await pool.query(spatialQuery, [longitude, latitude]);
    
    if (geoCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Localização fora do polígono de cobertura ativa.' });
    }

    const authority = geoCheck.rows[0];

    // Gravação do relatório geoespacial
    const insertReport = `
      INSERT INTO reports (user_id, geom, accuracy_meters, category)
      VALUES ($1, ST_SetSRID(ST_Point($2, $3), 4326), $4, $5) RETURNING id;
    `;
    const reportRes = await pool.query(insertReport, [normalizedUserId, longitude, latitude, accuracy, category]);
    const reportId = reportRes.rows[0].id;

    // Vinculação e criação automática do Ticket Autárquico
    await pool.query('INSERT INTO tickets (report_id, authority_id) VALUES ($1, $2)', [reportId, authority.id]);

    res.status(201).json({
      success: true,
      reportId,
      encaminhadoPara: authority.name,
      contactoAlvo: authority.contact_email
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro no motor de processamento espacial do servidor.' });
  }
});

// Global error handler (prevents unhandled async errors from becoming silent 500s)
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[backend] Unhandled error:', err);
  res.status(500).json({ error: 'Erro interno do servidor.' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor Guardiões a rodar na porta ${PORT}`));
