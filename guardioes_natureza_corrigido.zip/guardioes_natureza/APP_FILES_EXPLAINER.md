# Guardiões da Natureza — Arquivos e Pastas (explicação completa)

Este documento descreve **todas as pastas e arquivos** visíveis/identificados no repositório **guardioes_natureza** (neste snapshot), com foco em:
- Responsabilidade de cada arquivo
- Como ele se conecta com os outros
- Quais dados/estado ele cria, lê, persiste ou transforma
- Fluxos principais (SPA web, API backend, banco/PostGIS, e mock mobile)

> Observação: não há “limite de texto” aqui por design; se algum arquivo existir mas não estiver listado neste snapshot, ele não entra na explicação.

---

## Estrutura geral do projeto

O repositório está dividido em 4 áreas principais:

1. **`web/`**: Frontend SPA (Single Page Application) em JavaScript (ES Modules). Usa um “router” simples e um “store” global com persistência em `localStorage`.
2. **`backend/`**: API HTTP Node.js (Express) para receber um reporte e fazer georoteamento via PostGIS.
3. **`database/`**: Script SQL de schema (PostgreSQL + PostGIS) para criar tipos, tabelas e constraints.
4. **`mobile/`**: Aplicação Flutter (provavelmente protótipo/mocked) com duas abas e formulário simples.

Arquivos “raiz” relevantes:
- `TODO.md`
- `errors-report.md`

---

# Raiz (arquivos no diretório principal)

## `errors-report.md`

Este arquivo é um relatório de problemas encontrado por inspeção estática do código.

- Ele contém uma seção de **Backend**:
  - registra um problema operacional anterior de **porta em uso** (`EADDRINUSE`) quando rodou o servidor duas vezes.
  - registra um ponto que foi corrigido: **validação de request** e semântica quando `DATABASE_URL` não existe.
  - menciona que foi adicionado um **global error handler** no Express.
- Ele contém uma seção de **Web**:
  - chama atenção para risco de **mutação por referência** (design risk) em `web/state/store.js`.
  - comenta que `rawSetState` existe mas não é usado (dead code).
- Ele contém uma seção de **Web** adicional:
  - aponta variável não usada `nextSettings` em `web/screens/screen-profile.js` (apesar de isso não impedir execução).
- Ele contém uma seção de **Mobile**:
  - observa que o app mobile parece ser um “mock” mínimo, então não é completo como produto.
- Por fim, um **Summary**:
  - destaca o gap real de correção (validação do `/api/reports`) como “corrigido”
  - cita que DB execução e Flutter build/analyze não foram totalmente validados neste snapshot.

Em termos de engenharia, `errors-report.md` funciona como uma “lista de verificação” (debug/QA) e não como código executável.

---

## `TODO.md`

Este arquivo descreve um plano/estado de implementação.

- Seção **Web (SPA) — DONE**:
  - registra que `web/state/store.js` foi corrigido para não depender diretamente de `crypto.randomUUID()`.
  - registra que ações/persistência para settings do perfil foram adicionadas e que remoção de um `store.setState?.({})` inválido foi feita.
  - registra que `web/screens/screen-profile.js` foi atualizado para salvar settings via store.
- Seção **Backend (Node/Express) — NEXT**:
  - lista tarefas pendentes, especialmente:
    - validação mais robusta de `/api/reports`
    - garantir que o servidor inicie sem rejections não tratadas
- Seção **Database — NEXT**:
  - tarefa de verificar se `database/schema.sql` executa corretamente no alvo real (PostGIS/enum/tabelas/constraints).
- Seção **Mobile (Flutter) — NEXT**:
  - tarefa de rodar `flutter analyze` / `flutter build`.
- Seção **Verification — NEXT**:
  - inclui smoke test do web (rotas) e validação por console.

`TODO.md` também não é código; é documentação operacional.

---

# Pasta `backend/`

## `backend/package.json`

Configuração do pacote Node do backend.

- `name`: `guardioes-natureza-backend`
- `version`: `1.0.0`
- `description`: “API Core com Roteamento Espacial PostGIS”
- `main`: `server.js`
- `scripts`:
  - `start`: `node server.js`
- `dependencies`:
  - `express`: framework web
  - `pg`: driver PostgreSQL

Não há dependências de desenvolvimento listadas neste arquivo (apenas o lockfile existe).

---

## `backend/package-lock.json`

Lockfile gerado pelo npm.

- Ele fixa versões transitivas do `express` e `pg`.
- Contém uma grande árvore de dependências (body-parser, accepts, etc.).

Este arquivo garante reprodutibilidade do build/instalação.

---

## `backend/server.js`

Arquivo principal do backend (Express + Postgres via `pg`).

### Responsabilidade
Expor um endpoint:
- **POST `/api/reports`**

O endpoint:
1. Garante que o banco está configurado (`DATABASE_URL`).
2. Valida o body para evitar falhas de conversão/NaN e reduzir risco de erros do PostGIS.
3. Consulta a tabela `authorities` usando **ST_Contains** com geometria em SRID 4326.
4. Insere um registro em `reports` com ponto e precisão.
5. Cria um `ticket` ligando `report_id` e `authority_id`.
6. Retorna um payload com informações para o frontend.

### Detalhes importantes do fluxo
- `app.use(express.json())`: habilita parsing de JSON.
- `const pool = new Pool({ connectionString: process.env.DATABASE_URL })`: cria pool com `pg`.
- `dbConfigured`:
  - `let dbConfigured = !!process.env.DATABASE_URL;`
  - se ausente, imprime warning.
- Listener de erro do pool: `pool.on('error', ...)`.

#### Validação básica do request
Ele extrai:
- `userId`
- `latitudeRaw`, `longitudeRaw`, `accuracyRaw`
- `wasteType` (extraído mas **não usado** no SQL atual)

Converte:
- `latitude = Number(latitudeRaw)`
- `longitude = Number(longitudeRaw)`
- `accuracy = Number(accuracyRaw)`

Regras:
- `latitude` finita e entre `-90..90`
- `longitude` finita e entre `-180..180`
- `accuracy` finita e `accuracy <= 50`
- `userId` deve ser definido e conversível em número finito.

Retornos de erro:
- `400` com mensagem específica por parâmetro inválido

#### Consulta espacial
SQL (string template) seleciona:
- `id, name, contact_email`
- de `authorities`
- usando:
  - `ST_Contains(geom, ST_SetSRID(ST_Point($1,$2), 4326))`
  - com parâmetros recebidos como `[longitude, latitude]`
- `LIMIT 1`.

Se não houver `rows.length`, retorna:
- `404`: “Localização fora do polígono...”

#### Inserção de report
Insere em `reports`:
- `user_id`
- `geom`: `ST_SetSRID(ST_Point($2, $3), 4326)`
- `accuracy_meters`

Retorna `reportId` via `RETURNING id`.

#### Inserção de ticket
Executa:
- `INSERT INTO tickets (report_id, authority_id) VALUES ($1, $2)`

#### Respostas
- Sucesso: `201` com:
  - `success: true`
  - `reportId`
  - `encaminhadoPara` (authority.name)
  - `contactoAlvo` (authority.contact_email)

#### Tratamento de erro global
Há:
- `try/catch` em torno da lógica do endpoint (retorna `500` se falhar no PostGIS/DB).
- e também:
  - `app.use((err, req, res, next) => { ... })` para capturar erros não previstos.

### Observações de acoplamento
O backend assume:
- tabelas `authorities`, `reports`, `tickets`
- colunas específicas (`geom` em `authorities`, etc.)
- enums `ticket_state` criados no SQL

Logo a pasta `database/` é parte do “contrato” do backend.

---

# Pasta `database/`

## `database/schema.sql`

Script SQL para PostgreSQL + PostGIS.

### Responsabilidade
Criar:
- extensão PostGIS
- tipos enums
- tabelas principais:
  - `users`
  - `authorities`
  - `reports`
  - `tickets`
- indexes espaciais com GIST

### Componentes
#### PostGIS
- `CREATE EXTENSION IF NOT EXISTS postgis;`

#### Enums
- `authority_type`: `'Junta', 'Câmara', 'Governo'`
- `ticket_state`: `'Novo', 'Encaminhado', 'Em_Tratamento', 'Resolvido', 'Arquivado'`
- `waste_type`: `'Plástico', 'Vidro', 'Metal', 'Volumoso', 'Ribeira_Poluída', 'Outro'`

> Nota: o backend atual não persiste `wasteType` (está “unused” no endpoint).

#### Tabela `users`
- `id SERIAL PRIMARY KEY`
- `nickname` unique not null
- `email` unique
- `role` default `'user'`
- `school_name`
- `created_at` default current_timestamp

#### Tabela `authorities`
- `id` serial PK
- `name`
- `type authority_type`
- `geom MULTIPOLYGON(4326)`
- `contact_email`
- index espacial:
  - `CREATE INDEX idx_authorities_geom ON authorities USING GIST(geom);`

#### Tabela `reports`
- `id` serial PK
- `user_id INT REFERENCES users(id) ON DELETE SET NULL`
- `geom GEOMETRY(Point, 4326)`
- `accuracy_meters NUMERIC(5,2)`
- `created_at` default current_timestamp
- index espacial:
  - `CREATE INDEX idx_reports_geom ON reports USING GIST(geom);`

#### Tabela `tickets`
- `id` serial PK
- `report_id INT UNIQUE REFERENCES reports(id) ON DELETE CASCADE`
- `authority_id INT REFERENCES authorities(id)`
- `state ticket_state DEFAULT 'Novo'`
- `sent_at` default current_timestamp

### Contrato com o backend
- O endpoint faz `ST_Contains(geom, ST_Point(...))`, então `geom` em `authorities` deve ser um tipo compatível com `ST_Contains` e usar SRID 4326.
- O endpoint inserirá `reports.geom` como `Point` SRID 4326.
- O endpoint cria `tickets` sem setar `state` (logo default 'Novo' deve existir).

---

# Pasta `web/`

## `web/index.html`

Arquivo HTML principal da SPA.

### Responsabilidade
- Define layout base (header com nav, main com container de app).
- Define CSS embutido para estética.
- Carrega o módulo principal: `<script type="module" src="/web/app.js"></script>`.

### Componentes-chave
- Header:
  - cinco “tabs” com `data-route`: `/`, `/map`, `/report`, `/challenges`, `/profile`.
- Main:
  - `<div id="app"><div class="card">Carregando…</div></div>` onde o SPA injeta telas.
- Toast:
  - `<div class="toast" id="toast" role="status" aria-live="polite"></div>`

O JS do `web/app.js` usa `document.getElementById('app')` e `toast`.

---

## `web/app.js`

Ponto de entrada do frontend web (SPA).

### Responsabilidade
1. Criar store global (`createStore`).
2. Criar router (`new Router`).
3. Definir rotas e renderizadores para cada tela.
4. Fazer wiring dos cliques na navegação.
5. Iniciar router e bootstrap do store.

### Fluxo
- Importa:
  - `createStore` de `./state/store.js`
  - `Router` de `./router/router.js`
  - renderers:
    - `renderHome`
    - `renderMap`
    - `renderReport`
    - `renderChallenges`
    - `renderProfile`

- Monta `root` e `toastEl`.

- Implementa `toast(msg, tone='ok')`:
  - atualiza texto
  - muda `borderColor` conforme tone (`danger` vs ok)
  - adiciona classe `show`
  - remove após 2.4s

- Cria store com callback `onToast`:
  - `const store = createStore({ onToast: toast });`

- Cria router com `mode: 'history'` e callback `onRoute`.

`onRoute` faz um `switch(path)` para chamar o renderer correspondente:
- `/` -> `renderHome({ root, store, router })`
- `/map` -> `renderMap(...)`
- `/report` -> `renderReport(...)`
- `/challenges` -> `renderChallenges(...)`
- `/profile` -> `renderProfile(...)`

- `wireNav()`:
  - adiciona listener de click no `#nav`
  - usa `closest('[data-route]')`
  - chama `router.navigate(route)`

- Mount:
  - `router.start()`
  - `store.bootstrap()`

### Acoplamento
As telas recebem sempre:
- `root` (container DOM)
- `store` (estado e ações)
- `router` (navegação)

---

## Pasta `web/router/`

### `web/router/router.js`

Implementação simples de um router.

#### Responsabilidade
- Suportar `mode: 'history'` (usado) e placeholder para `hash`.
- Normalizar paths.
- Disparar callback `onRoute` quando:
  - start
  - navegação via `navigate`
  - back/forward (popstate)

#### API
- `constructor({ mode='history', onRoute } = {})`
  - salva `mode` e `onRoute`
  - cria handler bound para `popstate`

- `start()`:
  - `window.addEventListener('popstate', this._boundPop);`
  - `_emit()` com path atual

- `navigate(path)`:
  - normaliza
  - se history:
    - compara com `window.location.pathname`
    - faz `window.history.pushState({}, '', normalized)` e chama `_emit(normalized)`
  - se hash: (não usado)

- `_emit(pathOverride)`:
  - calcula `path = pathOverride ?? this._normalize(window.location.pathname)`
  - chama `this.onRoute?.({ path })`

- `_normalize(path)`:
  - garante `/` inicial
  - remove trailing slash exceto quando `/`

### Observação
O router é “controlador de UI” somente; não carrega dados.

---

## Pasta `web/state/`

### `web/state/storage.js`

Camada de persistência com `localStorage`.

#### Constantes
- `KEY = 'guardioes_natureza_state_v1'`

#### Funções
- `persist(state)`:
  - `localStorage.setItem(KEY, JSON.stringify(state))`
  - swallow de erros (catch vazio)

- `load()`:
  - lê `localStorage.getItem(KEY)`
  - se não existir retorna `null`
  - tenta `JSON.parse(raw)`
  - se falhar (parse/quota/blocked) retorna `null`

### Contrato
O store assume que o JSON lido tem formato compatível.

---

### `web/state/state.js`

Cria o estado inicial do SPA.

#### Responsabilidade
Exportar `createInitialState()`.

#### Conteúdo do estado inicial
Estrutura:
- `profile`
  - `id`: `'local'`
  - `name`: `'Guardião(a)'`
  - `createdAt`: `Date.now()`
  - `settings`:
    - `notificationsEnabled: true`
    - `reduceMotion: false`
- `notifications` (array):
  - `n1`: bem-vindo, route `/challenges`
  - `n2`: ajuda rápida, route `/map`
  - campos: `id`, `title`, `body`, `createdAt`, `read`, `route`
- `reports`: lista vazia `[]`
- `mapFilters`:
  - `types`: `{ desmatamento: true, lixo: true, incendio: true }`
  - `onlyNearby: false`
- `challenges` (array):
  - `first_report`: target 1
  - `report_eco`: target 5
  - `photo_report`: target 3
  - campos: `id`, `title`, `description`, `target`, `value`, `completed`, `trophy`

O estado é usado por `web/state/store.js` para bootstrap e atualizações.

---

### `web/state/store.js`

O “cérebro” do estado global.

#### Responsabilidade
- Manter estado em memória.
- Persistir mudanças em `localStorage`.
- Notificar assinantes (listeners).
- Expor ações para manipular perfil, notificações, reportes, desafios e filtros do mapa.

#### Interface externa (retorna um objeto)
`createStore({ onToast } = {})` devolve:
- `getState()`
- `subscribe(fn)`
- `markNotificationRead(id)`
- `addNotification(note)`
- `updateProfile({ name })`
- `updateSettings({ notificationsEnabled, reduceMotion })`
- `addReport({ type, location, desc, photoSimulated })`
- `setMapFilters(filters)`
- `toast: onToast`

#### Internamente
- `listeners = new Set()`

##### UUID safe helper
Define `safeUUID()`:
- tenta `globalThis.crypto?.randomUUID`
- fallback: gera string com padrão UUIDv4-like substituindo `[xy]`.

Essa decisão evita runtime crashes em navegadores onde `crypto.randomUUID` não existe.

##### Estado
- `let state = load() ?? createInitialState();`

> Observação do relatório de erros: o código usa atualizações imutáveis em várias partes, mas mantém `state` referenciando objetos do parse. Existem riscos conceituais de “mutation by reference” em certos cenários, mas isso não necessariamente causa bug agora.

##### `getState()`
Retorna `state` (por referência).

##### `setState(partial)`
- faz merge: `state = { ...state, ...partial }`
- persiste
- chama `for (const l of listeners) l(state)`

##### `bootstrap()`
Garante que chaves essenciais existem mesmo se storage vier parcial:
- se não tem `state.profile` => cria do initial
- se não tem `state.notifications` => cria
- se não tem `state.reports` => cria
- se não tem `state.challenges` => cria
- se não tem `state.mapFilters` => cria

Então persiste e chama listeners.

#### Ações (detalhadas)

##### `markNotificationRead(id)`
- mapeia `state.notifications` criando novos objetos quando `x.id===id`
- define `read:true` e `readAt:Date.now()`
- chama `setState({ notifications: n })`

##### `addNotification(note)`
- cria uma nova lista:
  - `[note, ...state.notifications].slice(0, 20)`
- chama `setState({ notifications: ... })`

##### `updateProfile({ name })`
- normaliza `name`:
  - `clean = (name ?? '').toString().trim()`
- faz merge:
  - `profile: { ...state.profile, name: clean || state.profile.name }`

##### `updateSettings({ notificationsEnabled, reduceMotion } = {})`
- garante boolean coalescing com defaults:
  - `notificationsEnabled: !!(notificationsEnabled ?? state.profile?.settings?.notificationsEnabled)`
  - `reduceMotion: !!(reduceMotion ?? state.profile?.settings?.reduceMotion)`

E persiste em `profile.settings`.

##### `addReport({ type, location, desc, photoSimulated })`
Responsabilidade: simular criação do reporte e efeitos colaterais (challenges e notificações).

Passos:
1. Cria `report` com:
   - `id: safeUUID()`
   - `type`
   - `location`
   - `desc`
   - `photoSimulated: !!photoSimulated`
   - `createdAt: Date.now()`
   - `status: 'pending'`
2. Atualiza lista `reports`:
   - `reports = [report, ...state.reports]`
3. Atualiza `challenges` iterando `state.challenges.map`:
   - `report_eco`:
     - incrementa `value` em 1
     - atualiza `completed` se `value>=target`
   - `first_report`:
     - só marca concluído se ainda não houve reportes (“already” via `state.reports.length>=1`)
   - `photo_report`:
     - incrementa em 1 apenas se `report.photoSimulated`
4. Cria uma notificação “real” para o usuário com route `/report`.
5. Faz `setState({ reports, challenges, notifications: [note,...].slice(0,20) })`
6. Chama `onToast?.('Reporte enviado com sucesso!','ok')`
7. Simula aprovação com `setTimeout` de 1100ms:
   - atualiza report status para `'approved'` e `approvedAt`
   - adiciona uma nova notificação “Verificação concluída” via `addNotification`.

> Observação: o endpoint real do backend **não é chamado** por esse store. A UI usa simulação.

##### `setMapFilters(filters)`
- `setState({ mapFilters: { ...state.mapFilters, ...filters } })`

---

## Pasta `web/ui/`

### `web/ui/dom.js`

Utilitário para DOM.

- `export function html(str)`:
  - cria `template`
  - `t.innerHTML = str.trim()`
  - retorna `t.content.firstElementChild`

Esse helper padroniza a forma de criar elementos para telas.

---

## Pasta `web/screens/`

Cada arquivo exporta uma função `renderX({ root, store, router })` responsável por:
- limpar `root` (`root.innerHTML = ''`)
- gerar HTML via `html()`
- anexar e fazer wiring de eventos do DOM

### `web/screens/screen-home.js`

Tela Home (dashboard) do SPA.

#### O que ela mostra
- KPI de `unreadCount` (notificações não lidas)
- “Próxima missão” com base na primeira notificação não lida
- Atalhos:
  - botão para ir ao Mapa (`/map`)
  - botão para ir ao Reportar (`/report`)
- Um bloco de “Estado global”

#### Eventos
- `homeMissionBtn.onclick`:
  - marca a notificação selecionada como lida
  - navega para `nextN.route || '/challenges'`
- `markAllBtn.onclick`:
  - marca todas notificações não lidas como lidas
- `#goMap` e `#goReport` navegam para respectivas rotas.

---

### `web/screens/screen-map.js`

Tela do “mapa” (simulado).

#### Responsabilidade
- Renderizar uma “área de mapa” visualmente (canvas-like layout via div).
- Apresentar hotspots fictícios (com tipos: `lixo`, `desmatamento`, `incendio`).
- Aplicar filtros baseados em `state.mapFilters`.
- Permitir que o usuário “clique em um hotspot” para selecionar um contexto e iniciar o flow em `/report`.

#### Estrutura interna
- `ICONS` mapeia tipo -> emoji
- `formatTime(ts)` converte timestamp para `pt-BR`

#### Hotspots simulados
`hotspots` é um array com 3 entradas e coordenadas percentuais (`x`,`y`), e `createdAt` randomizado.

#### Filtros
- `types`: lê `state.mapFilters.types`
- `enabledTypes`: lista de tipos com `true`
- `filtered`: filtra hotspots por tipo
- `onlyNearby`: se true, faz filtro adicional `h.x < 55` (simulação)

#### Render
- Monta duas colunas:
  1. Controles de filtros e “Popups” (botões posicionados em percentual)
  2. Lista de hotspots filtrados

Cada hotspot vira:
- um botão no “mapCanvas” (com `data-hotspot-id`)
- e um item na lista com um botão “Reportar aqui”.

#### Eventos
- `#applyFilters`:
  - coleta checkboxes `data-type`
  - monta `typesNext`
  - lê `#onlyNearby.checked`
  - chama `store.setMapFilters({ types: typesNext, onlyNearby })`
  - rerender chamando `router.navigate('/map')`.
- `#resetFilters`:
  - set defaults (3 tipos true, onlyNearby false)
  - rerender via navigate

#### Iniciar fluxo de report
Função `startReportFromHotspot(hid)`:
- encontra hotspot no array local `hotspots`
- chama `store.addNotification(...)` mas na prática usa o store para adicionar uma notificação “A preparar reporte…”
- chama `store.toast?.('Hotspot selecionado!', 'ok')`
- `store.setMapFilters({ lastHotspot: hid })`
- navega para `/report`.

> Nota: O store não define explicitamente `lastHotspot` no estado inicial; o `setMapFilters` usa spread, então essa chave aparece dinamicamente.

#### Importante: UUID
Dentro do `startReportFromHotspot`, ele usa `crypto.randomUUID()` diretamente ao adicionar notificação.

> Isso contrasta com o `safeUUID()` do store. O arquivo `errors-report.md` menciona correções anteriores em `web/state/store.js` mas aqui existe ainda um uso direto; isso pode quebr ar em navegadores sem `crypto.randomUUID`.

---

### `web/screens/screen-report.js`

Tela “Reportar” com um fluxo em 2 etapas (detalhes + câmara simulada).

#### Estrutura
- HTML em duas colunas:
  1. Card “1) Detalhes”
     - select de tipo
     - input de local
     - textarea descrição
     - botão “Avançar para captura”
  2. Card “2) Câmara simulada”
     - canvas `#cam`
     - botões “Capturar” e “Usar captura”
     - seção de confirmação
     - botão “Enviar reporte”

#### Constantes
- `REPORT_TYPES` array com:
  - `lixo`, `desmatamento`, `incendio`

#### Frame “câmara simulada”
Função `drawSimulatedCameraFrame(canvas,{seed})`:
- obtém `ctx`
- desenha:
  - fundo escuro
  - gradiente verde
  - scanlines
  - vignette
  - HUD com textos (“CÂMARA SIMULADA”, “Captura: #seed”)
  - um retângulo de focus e um marcador circular.

Ela é usada para:
- renderizar o canvas no começo
- redesenhar ao clicar “Capturar” (seed incrementa)

#### Escolha de tipo e contexto
- Lê `state.mapFilters.lastHotspot` se existir
- Mesmo que o hotspot exista, o código escolhe `pickedType` como um random do `REPORT_TYPES` (usa `randomFrom`), não o tipo do hotspot.

#### Estado local da UI
- `captured` (não usado para lógica final, mas representa intenção)
- `photoSimulated` (usada para habilitar submissão)

#### updateSummary()
- Monta texto `confirmSummary` com tipo/local e status “captura simulada”
- Determina habilitação do botão `#submitBtn` via condição:
  - `type && location && desc && photoSimulated`

#### Eventos
- `#goCamera`:
  - scroll smooth para a área da coluna direita
- `#captureBtn`:
  - incrementa seed e redesenha canvas
  - seta `captured=true` e `photoSimulated=true`
  - habilita `#usePhotoBtn`
- `#usePhotoBtn`:
  - só muda UI e desabilita botão
- `#submitBtn`:
  - faz `window.confirm`
  - desabilita controles e muda status para “enviando…”
  - chama `store.addReport({ type, location, desc, photoSimulated })`
  - injeta um “spinner”/barra de progresso visual
  - após 750ms:
    - muda status para “enviado (simulado)”
    - navega para `/challenges`

#### Acoplamento com backend
Nenhuma chamada HTTP existe aqui. Tudo depende do store simulado.

---

### `web/screens/screen-challenges.js`

Tela de “Desafios” e progressão.

#### Responsabilidade
- Exibir lista de desafios com barra de progresso.
- Exibir troféus desbloqueados.
- Exibir últimos reportes com base no store.
- Oferecer atalhos para `/map` e `/report`.

#### Funções auxiliares
- `pct(c)` retorna `(c.value/c.target)*100` arredondado.
- `formatMaybeDate(ts)` converte timestamp ou retorna string vazia.
- `trophyList(challenges)` gera string concatenada de troféus de desafios completos.

#### Render
- Barra de progresso em cada item usando `width:${pct(c)}%`.
- Status textual:
  - `c.value/c.target` e `c.completed ? 'Completado!' : 'Em progresso'`

#### Listas
- Últimos reportes:
  - `state.reports.slice(0,4)`
  - exibe `r.type.toUpperCase()`, `r.status`, `r.location` e data

#### Eventos
- botões:
  - `#backHome` => `/`
  - `#goMap` => `/map`
  - `#goReport` => `/report`

---

### `web/screens/screen-profile.js`

Tela de perfil local e histórico.

#### Responsabilidade
- Editar nome
- Exibir histórico de reports e notificações
- Configurar settings (persistidos via store/localStorage)

#### Render
Estrutura com duas colunas:
1. Perfil/editar nome + settings
2. Histórico de reports e notificações

#### Eventos de nome
- `#saveName`:
  - chama `store.updateProfile({ name: nameInput.value })`
  - `store.toast?.('Nome atualizado!', 'ok')`
  - navega `/profile` para rerender

- `#resetState`:
  - remove a key do localStorage: `'guardioes_natureza_state_v1'`
  - navega para `/`
  - `location.reload()`

> Observação: `errors-report.md` menciona `nextSettings` como variável não usada; mas isso não aparece diretamente no trecho visível do arquivo carregado no snapshot.

#### Eventos de settings
- `#saveSettings`:
  - lê checkboxes:
    - `#notifEnabled`
    - `#reduceMotion`
  - chama `store.updateSettings({ notificationsEnabled, reduceMotion })`
  - mostra toast
  - rerender por navegação

#### Eventos de notificações
- para cada botão com `data-notif-route`:
  - define `onclick` para:
    - encontrar notificação correspondente por `route` e primeira não lida
    - marcar como lida se existir
    - navegar para `route`

Esse comportamento conecta a lista de notificações com o fluxo de navegação.

---

# Pasta `mobile/`

## `mobile/pubspec.yaml`

Manifest do app Flutter.

- `name`: implicitamente pela pasta
- `description`: “Aplicação Mobile dos Guardiões da Natureza (Gamificação + Reportes)”
- `version`: `1.0.0+1`
- `environment`:
  - `sdk: ">=3.0.0 <4.0.0"`
- `dependencies`:
  - `flutter` via SDK
- `dev_dependencies`:
  - `flutter_test`
  - `flutter_lints: ^3.0.0`
- `flutter`:
  - `uses-material-design: true`

---

## `mobile/analysis_options.yaml`

Configurações do linter Flutter/Dart.

- Inclui `package:flutter_lints/flutter.yaml`
- Regras específicas:
  - `prefer_const_constructors`
  - `prefer_const_declarations`

---

## `mobile/lib/main.dart`

Entrada do app Flutter.

### Responsabilidade
Criar um app Material com duas rotas (na prática, abas via BottomNavigationBar):
- Aba 0: formulário “Reportar” com mock
- Aba 1: tela “Mapa” mock

### Estrutura
- `main()` => `runApp(const GuardioesApp());`
- `GuardioesApp extends StatelessWidget`:
  - retorna `MaterialApp`
  - configura tema com Material3
  - define `home: const HomeScreen()`.

### HomeScreen
- `HomeScreen extends StatefulWidget`
- `_HomeScreenState` mantém:
  - `_currentTab` (0 ou 1)
  - `_categoriaSelecionada` (String?)

#### build()
- `Scaffold`:
  - `AppBar` com título
  - `body`:
    - se `_currentTab==0` => `_buildReportForm()`
    - senão => `_buildMapMock()`
  - `bottomNavigationBar`:
    - dois itens:
      - “Reportar” com `Icons.camera_alt`
      - “Mapa” com `Icons.map`
    - `onTap` => `setState(() => _currentTab = index)`

#### `_buildReportForm()`
- `SingleChildScrollView`
- Layout:
  - placeholder “foto” (container cinza)
  - Dropdown `DropdownButtonFormField<String>` com categorias:
    - `Plástico`, `Vidro`, `Metal`, `Volumoso`, `Ribeira_Poluída`
  - botão `SUBMETER OCORRÊNCIA`

Ao clicar no botão, apenas mostra `SnackBar` (sem integração real com backend).

#### `_buildMapMock()`
- retorna um container com fundo e texto “Camada de Mapas Ativa\n(Clusters & Trilhos Oficiais)”.

### Acoplamento
Este app não integra com o backend nem com o store web; é protótipo local.

---

# Conclusão: como as peças se conectam

1. **Web SPA (`web/`)**
   - `web/index.html` fornece o container e carrega `web/app.js`.
   - `web/app.js` monta store + router e chama renderers.
   - `web/state/store.js` mantém estado e persistência.
   - telas em `web/screens/` renderizam UI com base no estado e chamam ações do store.

2. **Backend (`backend/`)**
   - `backend/server.js` expõe `POST /api/reports` e usa PostGIS para identificar `authority` com base no ponto.
   - O backend espera schema criado em `database/schema.sql`.

3. **Database (`database/`)**
   - `schema.sql` define tabelas e enums.
   - É o contrato físico do backend.

4. **Mobile (`mobile/`)**
   - `mobile/lib/main.dart` é um mock simples.
   - Não chama backend no snapshot atual.

---

# Lista de arquivos (checklist do snapshot)

- `errors-report.md`
- `TODO.md`
- `backend/server.js`
- `backend/package.json`
- `backend/package-lock.json`
- `database/schema.sql`
- `mobile/lib/main.dart`
- `mobile/pubspec.yaml`
- `mobile/analysis_options.yaml`
- `web/index.html`
- `web/app.js`
- `web/router/router.js`
- `web/state/state.js`
- `web/state/storage.js`
- `web/state/store.js`
- `web/ui/dom.js`
- `web/screens/screen-home.js`
- `web/screens/screen-map.js`
- `web/screens/screen-report.js`
- `web/screens/screen-challenges.js`
- `web/screens/screen-profile.js`

---

## Observações de consistência (importante)

- Existe **simulação** no store web (`addReport` atualiza estado e adiciona notificações) — não há chamada de rede no fluxo.
- O backend implementa `/api/reports` real via PostGIS — mas esse fluxo não está ligado ao frontend no snapshot.

Se no futuro for feito o “wire real” (chamar backend do frontend), os contratos de payload e a persistência real precisarão ser integrados (ex.: `wasteType`, `userId`, geocoordenadas e `accuracy`).

