-- Ativação da extensão geoespacial PostGIS
CREATE EXTENSION IF NOT EXISTS postgis;

-- Enumerações para estados e tipos de resíduos
CREATE TYPE authority_type AS ENUM ('Junta', 'Câmara', 'Governo');
CREATE TYPE ticket_state AS ENUM ('Novo', 'Encaminhado', 'Em_Tratamento', 'Resolvido', 'Arquivado');
CREATE TYPE waste_type AS ENUM ('Plástico', 'Vidro', 'Metal', 'Volumoso', 'Ribeira_Poluída', 'Outro');
-- Categoria do incidente reportado no ecrã "Reportar" da SPA web (distinto de waste_type,
-- que descreve o material e não é atualmente preenchido pelo frontend).
CREATE TYPE report_category AS ENUM ('lixo', 'desmatamento', 'incendio');

-- Tabela de Utilizadores
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    nickname VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE,
    role VARCHAR(20) DEFAULT 'user',
    school_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Autoridades Administrativas (Polígonos Municipais/Freguesias)
CREATE TABLE authorities (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type authority_type NOT NULL,
    geom geometry(MultiPolygon, 4326) NOT NULL,
    contact_email VARCHAR(100) NOT NULL
);
CREATE INDEX idx_authorities_geom ON authorities USING GIST(geom);

-- Tabela de Relatórios de Poluição
CREATE TABLE reports (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE SET NULL,
    geom GEOMETRY(Point, 4326) NOT NULL,
    accuracy_meters NUMERIC(5,2) NOT NULL,
    category report_category NOT NULL DEFAULT 'lixo',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_reports_geom ON reports USING GIST(geom);

-- Tabela de Tickets para Tramitação Autárquica
CREATE TABLE tickets (
    id SERIAL PRIMARY KEY,
    report_id INT UNIQUE REFERENCES reports(id) ON DELETE CASCADE,
    authority_id INT REFERENCES authorities(id),
    state ticket_state DEFAULT 'Novo',
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- Seed data: sem isto, ST_Contains nunca encontra nenhuma
-- autoridade e /api/reports responde sempre 404.
-- ============================================================

-- Utilizador "convidado" (id = 1), usado pelo frontend web enquanto
-- não existir sistema de contas real.
INSERT INTO users (nickname, role) VALUES ('convidado', 'guest');

-- Autoridade de cobertura para a ilha de São Miguel (bounding box larga;
-- substituir por polígonos reais por freguesia/concelho quando disponíveis).
INSERT INTO authorities (name, type, geom, contact_email) VALUES (
  'Câmara Municipal de Ponta Delgada',
  'Câmara',
  ST_SetSRID(
    ST_GeomFromText('MULTIPOLYGON(((-25.90 37.70, -25.90 37.90, -25.10 37.90, -25.10 37.70, -25.90 37.70)))'),
    4326
  ),
  'geral@cmpontadelgada.pt'
);