import 'package:flutter/material.dart';

void main() => runApp(const GuardioesApp());

class GuardioesApp extends StatelessWidget {
  const GuardioesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Guardiões da Natureza',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1B4332),
          primary: const Color(0xFF1B4332),
        ),
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentTab = 0;
  String? _categoriaSelecionada;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Guardiões da Natureza', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color(0xFF1B4332),
      ),
      body: _currentTab == 0 ? _buildReportForm() : _buildMapMock(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentTab,
        onTap: (index) => setState(() => _currentTab = index),
        selectedItemColor: const Color(0xFF2D6A4F),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.camera_alt), label: 'Reportar'),
          BottomNavigationBarItem(icon: Icon(Icons.map), label: 'Mapa'),
        ],
      ),
    );
  }

  Widget _buildReportForm() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 180,
            width: double.infinity,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(8)),
            child: const Center(child: Icon(Icons.add_a_photo, size: 50, color: Colors.grey)),
          ),
          const SizedBox(height: 15),
          const Text('Tipo de Resíduo Detectado:', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _categoriaSelecionada,
            hint: const Text('Selecione uma categoria'),
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            items: ['Plástico', 'Vidro', 'Metal', 'Volumoso', 'Ribeira_Poluída']
                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                .toList(),
            onChanged: (v) => setState(() => _categoriaSelecionada = v),
          ),
          const SizedBox(height: 25),
          SizedBox(
            width: double.infinity,
            height: 45,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF2D6A4F)),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Sincronizando reporte com georoteamento autárquico...'))
                );
              },
              child: const Text('SUBMETER OCORRÊNCIA', style: TextStyle(color: Colors.white)),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildMapMock() {
    return Container(
      color: Colors.green[50],
      child: const Center(
        child: Text('Camada de Mapas Ativa\n(Clusters & Trilhos Oficiais)', textAlign: Center),
      ),
    );
  }
}